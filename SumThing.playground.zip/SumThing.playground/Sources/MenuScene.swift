import UIKit
import PlaygroundSupport
import AVFoundation


public class SoundPlayer{
    
    static var buttonSound: AVAudioPlayer?
    
    static func playButtonSoundEffect(buttonName: String, audioFormat: String = "mp3"){
        
        guard let buttonSoundPath = Bundle.main.path(forResource: "\(buttonName)", ofType: audioFormat) else { return }
        
        let buttonSoundURL = URL(fileURLWithPath: buttonSoundPath)
        
        buttonSound = try? AVAudioPlayer(contentsOf: buttonSoundURL)
        
        buttonSound?.play()
    }
}

var isPlaying = false

public class MenuViewController : UIViewController {
    
    var player: AVAudioPlayer?
    
    let buttonPlay = UIButton()
    let label = UILabel()
    let myTitle = UIButton()
    let tutorial = UIButton()
    let about = UIButton()
    let menuStack = UIStackView()
    let mainStack = UIStackView()
    let squareText = UILabel()
    let mathText = UILabel()
    
    var soundTrack: AVAudioPlayer?
    
    var viewSize = UIScreen.main.bounds
    
    override public func loadView() {
        let view = UIView()
        self.view = view
        self.view.backgroundColor = UIColor(red: 1.0, green: 0.9, blue: 0.6, alpha: 0.95)
        
        setMenuStack()
        setMainStack()
        setTitle()
        setButtonPlay()
        setAbout()
        setSumText()
        setThingText()
        
        setSoundTrack(noteString: "gameSoundtrack")
        
        
    }
    
    func setMainStack(){
        mainStack.axis = .horizontal
        mainStack.distribution = .fill
        mainStack.spacing = 60
        mainStack.alignment = .center
        
        mainStack.frame = CGRect(x: 40, y: -60, width: 300, height: 600)
        
        view.addSubview(mainStack)
        
    }
    
    
    
    func setMenuStack() {
        menuStack.axis = .vertical
        menuStack.distribution = .fillEqually
        menuStack.spacing = 60
        menuStack.alignment = .center
        
        menuStack.frame = CGRect(x: 150, y: 130, width: 200, height: 600)
        
        view.addSubview(menuStack)
    }
    
    func setTitle () {
        myTitle.frame = CGRect(x: -30, y: 10, width: 420, height: 420)
        
        UIGraphicsBeginImageContext(myTitle.frame.size)
        UIImage(named: "menuIcon")?.draw(in: myTitle.bounds)
        let photo = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        myTitle.backgroundColor = UIColor(patternImage: photo)
        view.addSubview(myTitle)
        
    }
    
    func setButtonPlay(){
        buttonPlay.frame = CGRect(x: 110, y: 490, width: 150, height: 65)
        buttonPlay.setTitle("PLAY!", for: .normal)
        buttonPlay.backgroundColor = UIColor(red: 0.9, green: 0.5, blue: 0.25, alpha: 0.65)
        buttonPlay.layer.cornerRadius = 8.0
        buttonPlay.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 42)
        buttonPlay.layer.borderWidth = 0.5
        buttonPlay.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
        
        view.addSubview(buttonPlay)
        
        buttonPlay.addTarget(self, action: #selector(increasePlay), for: .touchDown)
        
        buttonPlay.addTarget(self, action: #selector(decreasePlay), for: .touchUpInside)
        
        
    }
    
    func setAbout () {
        about.frame = CGRect(x: 110, y: 570, width: 150, height: 65)
        about.setTitle("ABOUT ME", for: .normal)
        about.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 0.85)
        about.layer.cornerRadius = 8.0
        about.clipsToBounds = true
        about.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 24)
        about.layer.borderWidth = 0.5
        about.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
        view.addSubview(about)
        
        about.addTarget(self, action: #selector(changeAbout), for: .touchDown)
        
        about.addTarget(self, action: #selector(decreaseAbout), for: .touchUpInside)
    }
    
    
    func setTutorial() {
        tutorial.frame = CGRect(x: 170, y: 220, width: 150, height: 60)
        tutorial.setTitle("HOW TO PLAY", for: .normal)
        tutorial.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 0.95)
        tutorial.layer.cornerRadius = 8.0
        tutorial.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        
        view.addSubview(tutorial)
        
        tutorial.addTarget(self, action: #selector(changeTutorial), for: .touchDown)
        
        tutorial.addTarget(self, action: #selector(decreaseTutorial), for: .touchUpInside)
    }
    
    
    
    func configureLabel(){
        label.frame = CGRect(x: 10, y: 100, width: 100, height: 100)
        label.text = "Hello World!"
        label.textColor = .black
        
        view.addSubview(label)
    }
    
    func setSumText(){
        squareText.frame = CGRect(x: 116, y: 135, width: 160, height: 80)
        squareText.text = "SUM"
        squareText.textColor = UIColor(red: 1.0, green: 0.61, blue: 0.48, alpha: 1.0)
        squareText.font = UIFont(name: "Arial Rounded MT Bold", size: 47)
        
        view.addSubview(squareText)
    }
    
    func setThingText(){
        mathText.frame = CGRect(x: 140, y: 223, width: 250, height: 80)
        mathText.text = "THING"
        mathText.textColor = UIColor(red: 0.65, green: 0.71, blue: 1.0, alpha: 1.0)
        mathText.font = UIFont(name: "Arial Rounded MT Bold", size: 42)
        
        view.addSubview(mathText)
    }
    
    func setSoundTrack(noteString: String){
        
        guard let url = Bundle.main.url(forResource: noteString, withExtension: "mp3") else {return}
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            player?.numberOfLoops = -1
            
            
            guard let player = player else { return }
            if isPlaying == false {
                player.play()
                isPlaying = true
            }
            
        } catch let error {
            print(error.localizedDescription)
        }
    
    }

    
    @objc func increasePlay(sender: UIButton!) {
        
        UIView.animate(withDuration: 0.3) {

            self.buttonPlay.frame = CGRect(x: 107.5, y: 489, width: 155, height: 66)
        
        }
        
        SoundPlayer.playButtonSoundEffect(buttonName: "buttonClick ")
    }
    
    @objc func decreasePlay(sender: UIButton!){
        
        UIView.animate(withDuration: 0.3){
        
            self.buttonPlay.frame = CGRect(x: 110, y: 490, width: 150, height: 65)
        }
        

        present(tutorialViewController(), animated: true)
        PlaygroundSupport.PlaygroundPage.current.liveView = tutorialViewController()
    }
    
    @objc func changeTutorial(sender: UIButton!){
        
        UIView.animate(withDuration: 0.3){
            self.tutorial.frame = CGRect(x: -2.5, y: 169, width: 155, height: 61)
        }
    }
    
    @objc func decreaseTutorial(sender: UIButton!){
        
        UIView.animate(withDuration: 0.3){
            self.tutorial.frame = CGRect(x: 0, y: 170, width: 150, height: 60)
        }
    }
    
    @objc func changeAbout(sender: UIButton!){
        
        UIView.animate(withDuration: 0.3){
            self.about.frame = CGRect(x: 107.5, y: 569, width: 155, height: 66)
        }
        SoundPlayer.playButtonSoundEffect(buttonName: "buttonClick ")
    }
    
    @objc func decreaseAbout(sender: UIButton!){
        
        UIView.animate(withDuration: 0.3){
            self.about.frame = CGRect(x: 110, y: 570, width: 150, height: 65)
        }
        present(aboutViewController(), animated: true)
        PlaygroundSupport.PlaygroundPage.current.liveView = aboutViewController()
    }
    
    
    
}

