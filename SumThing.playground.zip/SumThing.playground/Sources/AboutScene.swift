import UIKit
import PlaygroundSupport
import AVFoundation


public class aboutViewController : UIViewController
{
    let squareSide = 65.0
    let firstSquare = UILabel()
    let secondSquare = UILabel()
    let thirdSquare = UILabel()
    let fourthSquare = UILabel()
    let fifthSquare = UILabel()
    
    let profilePic = UIButton()
    let aboutText = UITextView()
    let returnButton = UIButton()
    
    override public func loadView()
    {
        
        let view = UIView()
        
        view.backgroundColor = UIColor(red: 1.0, green: 0.9, blue: 0.6, alpha: 0.95)
        
        self.view = view
        
        setFiveSquares()
        setProfilePic()
        setAboutText()
        setReturnButton()
        animateSquares()
        
    }
    
    func setFiveSquares(){
        firstSquare.frame = CGRect(x: 400.0, y: 800.0, width: squareSide, height: squareSide)
        secondSquare.frame = CGRect(x: -100, y: 400.0, width: squareSide, height: squareSide)
        thirdSquare.frame = CGRect(x: 500, y: 300.0, width: squareSide, height: squareSide)
        fourthSquare.frame = CGRect(x: -100, y: 500.0, width: squareSide, height: squareSide)
        fifthSquare.frame = CGRect(x: 180, y: 900, width: squareSide, height: squareSide)
        
        
        firstSquare.layer.cornerRadius = 5
        secondSquare.layer.cornerRadius = 5
        thirdSquare.layer.cornerRadius = 5
        fourthSquare.layer.cornerRadius = 5
        fifthSquare.layer.cornerRadius = 5
        
        firstSquare.clipsToBounds = true
        secondSquare.clipsToBounds = true
        thirdSquare.clipsToBounds = true
        fourthSquare.clipsToBounds = true
        fifthSquare.clipsToBounds = true
        
        firstSquare.backgroundColor = .red
        secondSquare.backgroundColor = .red
        thirdSquare.backgroundColor = .red
        fourthSquare.backgroundColor = .red
        fifthSquare.backgroundColor = .red
        
        firstSquare.alpha = 0.0
        secondSquare.alpha = 0.0
        thirdSquare.alpha = 0.0
        fourthSquare.alpha = 0.0
        fifthSquare.alpha = 0.0
        
        firstSquare.textColor = .white
        secondSquare.textColor = .white
        thirdSquare.textColor = .white
        fourthSquare.textColor = .white
        fifthSquare.textColor = .white
        
        firstSquare.textAlignment = .center
        secondSquare.textAlignment = .center
        thirdSquare.textAlignment = .center
        fourthSquare.textAlignment = .center
        fifthSquare.textAlignment = .center
        
        firstSquare.text = "W"
        secondSquare.text = "W"
        thirdSquare.text = "D"
        fourthSquare.text = "C"
        fifthSquare.text = "19"
        
        firstSquare.font = UIFont(name: "Arial Rounded MT Bold", size: 50)
        secondSquare.font = UIFont(name: "Arial Rounded MT Bold", size: 50)
        thirdSquare.font = UIFont(name: "Arial Rounded MT Bold", size: 50)
        fourthSquare.font = UIFont(name: "Arial Rounded MT Bold", size: 50)
        fifthSquare.font = UIFont(name: "Arial Rounded MT Bold", size: 50)
        
        firstSquare.layer.borderWidth = 0.5
        secondSquare.layer.borderWidth = 0.5
        thirdSquare.layer.borderWidth = 0.5
        fourthSquare.layer.borderWidth = 0.5
        fifthSquare.layer.borderWidth = 0.5
        
        firstSquare.layer.borderColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 0.8).cgColor
        firstSquare.layer.borderColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.4).cgColor
        secondSquare.layer.borderColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.4).cgColor
        thirdSquare.layer.borderColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.4).cgColor
        fourthSquare.layer.borderColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.4).cgColor
        fifthSquare.layer.borderColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.4).cgColor
        
        
        view.addSubview(firstSquare)
        view.addSubview(secondSquare)
        view.addSubview(thirdSquare)
        view.addSubview(fourthSquare)
        view.addSubview(fifthSquare)
    }
    
    func setProfilePic(){
        profilePic.frame = CGRect (x: 300, y: -180, width: 140, height: 140)
        
        UIGraphicsBeginImageContext(profilePic.frame.size)
        UIImage(named: "profile")?.draw(in: profilePic.bounds)
        let photo = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        profilePic.backgroundColor = UIColor(patternImage: photo)
        profilePic.layer.cornerRadius = 70.0
        profilePic.addShadow()
        profilePic.alpha = 0.0
        
        view.addSubview(profilePic)
        
    }
    
    func animateSquares(){
        UIView.animate(withDuration: 4.5, animations:
            {
                self.firstSquare.alpha = 0.5
                self.secondSquare.alpha = 0.5
                self.thirdSquare.alpha = 0.5
                self.fourthSquare.alpha = 0.5
                self.fifthSquare.alpha = 0.5
                
                let affineTransform = CGAffineTransform(rotationAngle: CGFloat.pi)
                
                self.firstSquare.transform = affineTransform
                self.secondSquare.transform = affineTransform
                self.thirdSquare.transform = affineTransform
                self.fourthSquare.transform = affineTransform
                self.fifthSquare.transform = affineTransform
                
                self.firstSquare.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 0.65)
                self.secondSquare.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 0.65)
                self.thirdSquare.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 1.0)
                self.fourthSquare.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 0.65)
                self.fifthSquare.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 0.65)
                
                self.firstSquare.frame = CGRect(x: 14.0, y: 100.0, width: self.squareSide, height: self.squareSide)
                self.secondSquare.frame = CGRect(x: 84, y: 100.0, width: self.squareSide, height: self.squareSide)
                self.thirdSquare.frame = CGRect(x: 154, y: 100.0, width: self.squareSide, height: self.squareSide)
                self.fourthSquare.frame = CGRect(x: 224, y: 100.0, width: self.squareSide, height: self.squareSide)
                self.fifthSquare.frame = CGRect(x: 294, y: 100.0, width: self.squareSide, height: self.squareSide)
                
                self.profilePic.frame = CGRect (x: 114, y: 190, width: 140, height: 140)
                self.profilePic.alpha = 1.0
        })
        
        UIView.animate(withDuration: 0.3, delay: 4.3, animations:
            {
                self.firstSquare.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 1.0)
                self.secondSquare.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 1.0)
                self.thirdSquare.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 1.0)
                self.fourthSquare.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 1.0)
                self.fifthSquare.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 1.0)
                
                let affineTransform = CGAffineTransform(rotationAngle: CGFloat(Double.pi * 2))
                
                self.firstSquare.transform = affineTransform
                self.secondSquare.transform = affineTransform
                self.thirdSquare.transform = affineTransform
                self.fourthSquare.transform = affineTransform
                self.fifthSquare.transform = affineTransform
                
                self.firstSquare.transform = affineTransform
                self.secondSquare.transform = affineTransform
                self.thirdSquare.transform = affineTransform
                self.fourthSquare.transform = affineTransform
                self.fifthSquare.transform = affineTransform
                
                self.firstSquare.transform = affineTransform
                self.secondSquare.transform = affineTransform
                self.thirdSquare.transform = affineTransform
                self.fourthSquare.transform = affineTransform
                self.fifthSquare.transform = affineTransform
                
                self.aboutText.alpha = 1.0
                self.returnButton.alpha = 1.0
        })
    }
    
    func setAboutText(){
        
        self.aboutText.frame = CGRect(x: 14, y: 350, width: 345, height: 200)
        self.aboutText.backgroundColor = UIColor(red: 1.0, green: 0.9, blue: 0.6, alpha: 0.0)
        self.aboutText.textColor = .brown
        self.aboutText.font = UIFont(name: "Arial Rounded MT Bold", size: 18)
        self.aboutText.textAlignment = .center
        self.aboutText.alpha = 0.0
        self.aboutText.isUserInteractionEnabled = false
        
        self.aboutText.text = "My name is Henrique, and I am a 19 years old Brazilian programmer. I am engaged in educational projects as well as in software development, which led me to Apple Developer Academy. Going to WWDC would be significantly important for me to be in touch with the latest Apple technologies."
        
        view.addSubview(self.aboutText)
    }
    
    func setReturnButton () {
        self.returnButton.frame = CGRect(x: 96, y: 570, width: 180, height: 65)
        self.returnButton.setTitle("Return to menu", for: .normal)
        self.returnButton.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 0.85)
        self.returnButton.layer.cornerRadius = 8.0
        self.returnButton.clipsToBounds = true
        self.returnButton.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 20)
        self.returnButton.alpha = 0.0
        self.returnButton.layer.borderWidth = 0.5
        self.returnButton.layer.borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.3).cgColor
        
        view.addSubview(self.returnButton)
        
        self.returnButton.addTarget(self, action: #selector(self.returnToMenu), for: .touchUpInside)
        
    }
    
    @objc func returnToMenu(sender: UIButton!){
        
        SoundPlayer.playButtonSoundEffect(buttonName: "buttonClick ")
        
        PlaygroundSupport.PlaygroundPage.current.liveView = MenuViewController()
    }
    
    
}
