import UIKit
import PlaygroundSupport
import AVFoundation

public class tutorialViewController: UIViewController{
    
    
    let newSquare = UILabel()
    let negativeSquare = UILabel()
    let goalPrint = UIButton()
    let whiteBoard = UIView()
    let touchText = UITextView()
    let goalText = UITextView()
    let timerPrint = UIButton()
    let timerText = UITextView()
    let buttonPlay = UIButton()
    
    
    override public func loadView() {
        let view = UIView()
        self.view = view
        self.view.backgroundColor = UIColor(red: 1.0, green: 0.9, blue: 0.6, alpha: 0.95)
        
        
        setWhiteBoard()
        setGameSquares()
        setGoalPrint()
        setTouchText()
        setGoalText()
        setTimerPrint()
        setTimerText()
        setButtonPlay()
    }
    
    
    func setGameSquares(){
        
        newSquare.backgroundColor = UIColor(red: 0.65, green: 0.81, blue: 1.0, alpha: 0.9)
        newSquare.frame = CGRect(x: 92, y: 50, width: 90, height: 90)
        newSquare.layer.borderWidth = 0.2
        newSquare.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
        newSquare.layer.cornerRadius = 25.0
        newSquare.text = "6"
        newSquare.textColor = .white
        newSquare.textAlignment = .center
        newSquare.font = UIFont(name: "Arial Rounded MT Bold", size: 30)
        newSquare.clipsToBounds = true
        
        
        negativeSquare.backgroundColor = UIColor(red: 1.0, green: 0.61, blue: 0.58, alpha: 0.9)
        negativeSquare.frame = CGRect(x: 186, y: 50, width: 90, height: 90)
        negativeSquare.layer.borderWidth = 0.2
        negativeSquare.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
        negativeSquare.layer.cornerRadius = 25.0
        negativeSquare.text = "-2"
        negativeSquare.textColor = .white
        negativeSquare.textAlignment = .center
        negativeSquare.font = UIFont(name: "Arial Rounded MT Bold", size: 30)
        negativeSquare.clipsToBounds = true
        
        
        UIView.animate(withDuration: 1.5, delay: 0.0, options: [.repeat, .autoreverse], animations:  //options: [.repeat, .beginFromCurrentState]
            {
                
                self.newSquare.alpha = 0.5
                self.negativeSquare.alpha = 0.5
                
        })
        
        view.addSubview(negativeSquare)
        view.addSubview(newSquare)
    
        
    }
    
    func setWhiteBoard(){
        
        whiteBoard.frame = CGRect(x: 89, y: 47, width: 192, height: 96)
        
        whiteBoard.backgroundColor = UIColor(red: 1, green: 0.98, blue: 0.91, alpha: 1)
        whiteBoard.layer.cornerRadius = 8.0
        whiteBoard.layer.borderWidth = 0.5
        whiteBoard.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
        
        view.addSubview(whiteBoard)
    }
    
    func setGoalPrint(){
        
        goalPrint.frame = CGRect(x: 120, y: 230, width: 130, height: 130)
        UIGraphicsBeginImageContext(goalPrint.frame.size)
        UIImage(named: "goalPrint")?.draw(in: goalPrint.bounds)
        let photo = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        goalPrint.backgroundColor = UIColor(patternImage: photo)
        goalPrint.layer.cornerRadius = 20.0
        goalPrint.layer.borderWidth = 0.3
        goalPrint.layer.borderColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.2).cgColor
        
        view.addSubview(goalPrint)
    }
    
    func setTouchText(){
        
        self.touchText.frame = CGRect(x: 15, y: 140, width: 345, height: 100)
        self.touchText.textColor = .brown
        self.touchText.font = UIFont(name: "Arial Rounded MT Bold", size: 18)
        self.touchText.textAlignment = .center
        self.touchText.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.0)
        
        self.touchText.text = "Press any tile and the values will be summed! You can press again to deselect it."
        
        view.addSubview(self.touchText)
        
    }
    
    func setGoalText(){
        
        self.goalText.frame = CGRect(x: 15, y: 357, width: 345, height: 100)
        self.goalText.textColor = .brown
        self.goalText.font = UIFont(name: "Arial Rounded MT Bold", size: 18)
        self.goalText.textAlignment = .center
        self.goalText.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.0)
        
        self.goalText.text = "Sum the tiles to achieve the goal! You can select as many as you need."
        
        view.addSubview(self.goalText)
        
    }
    
    
    func setTimerPrint(){
        
        timerPrint.frame = CGRect(x: 120, y: 430, width: 130, height: 70)
        UIGraphicsBeginImageContext(timerPrint.frame.size)
        UIImage(named: "timerPrint")?.draw(in: timerPrint.bounds)
        let photo = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        timerPrint.backgroundColor = UIColor(patternImage: photo)
        timerPrint.layer.cornerRadius = 10.0

        timerPrint.layer.borderWidth = 0.3
        timerPrint.layer.borderColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.2).cgColor
        
        view.addSubview(timerPrint)
    }
    
    func setTimerText(){
        self.timerText.frame = CGRect(x: 15, y: 500, width: 345, height: 100)
        self.timerText.textColor = .brown
        self.timerText.font = UIFont(name: "Arial Rounded MT Bold", size: 18)
        self.timerText.textAlignment = .center
        self.timerText.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.0)
        
        self.timerText.text = "Get more time by reaching the goals!"
        
        view.addSubview(self.timerText)
    }
    
    func setButtonPlay(){
        buttonPlay.frame = CGRect(x: 110, y: 570, width: 150, height: 65)
        buttonPlay.setTitle("LET'S PLAY!", for: .normal)
        buttonPlay.backgroundColor = UIColor(red: 0.9, green: 0.5, blue: 0.25, alpha: 0.65)
        buttonPlay.layer.cornerRadius = 8.0
        buttonPlay.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 24)
        buttonPlay.layer.borderWidth = 0.5
        buttonPlay.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
        
        view.addSubview(buttonPlay)
        
        buttonPlay.addTarget(self, action: #selector(increasePlay), for: .touchDown)
        
        buttonPlay.addTarget(self, action: #selector(decreasePlay), for: .touchUpInside)
    }
    
    
    @objc func increasePlay(sender: UIButton!) {
        
        UIView.animate(withDuration: 0.3) {
            self.buttonPlay.frame = CGRect(x: 107.5, y: 569, width: 155, height: 66)
            
        }
        
        SoundPlayer.playButtonSoundEffect(buttonName: "buttonClick ")
    }
    
    @objc func decreasePlay(sender: UIButton!){
        
        UIView.animate(withDuration: 0.3){
            
            self.buttonPlay.frame = CGRect(x: 110, y: 570, width: 150, height: 65)
        }
        
        PlaygroundSupport.PlaygroundPage.current.liveView = gameScene()
    }
    
    
}
    
    
