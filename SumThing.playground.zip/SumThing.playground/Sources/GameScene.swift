import UIKit
import PlaygroundSupport
import AVFoundation

public class gameScene: UIViewController {
    
    
    public class gameSquare{
        public let button = UIButton()
        public var value = 0
        public var clicked = false
        
        init(value: Int, clicked: Bool) {
            self.value = value
            self.clicked = clicked
        }
        
    }
    
    var player: AVAudioPlayer?
    
    var menuViewController = UIViewController()
    
    var viewSize = UIScreen.main.bounds

    var actualSum:Int = 0
    var actualScore:Int = 0
    var actualGoal: Int = 0
    var actualTime = 10
    var actualRound = 0
    var squareRound = 0
    
    let firstStack = UIStackView()
    let secondStack = UIStackView()
    let thirdStack = UIStackView()
    let fourthStack = UIStackView()
    let fifthStack = UIStackView()
    let gameStack = UIStackView()
    
    let mainSquare = UIView()
    let timerSquare = UIView()
    
    let scoreSquare = UILabel()
    let goalSquare = UILabel()
    let gamePhrase = UILabel()
    let scoreText = UILabel()
    let goalText = UILabel()
    let goalWord = UILabel()
    
    let endGameSquare = UIView()
    let endOption = UIView()
    let endText = UILabel()
    let playAgainText = UILabel()
    let playAgain = UIButton()
    let backMenu = UIButton()
 
    
    
    
    weak var timeCounter: Timer?
    
    
    var valueSquare: [gameSquare] = []
    var choosenSquares: [UIButton] = []
    var timeArray: [UIView] = []
    
    override public func loadView() {
        let gameView = UIView()
        self.view = gameView
    
        self.view.backgroundColor = UIColor(red:1.0, green: 0.9, blue: 0.6, alpha: 0.95)
        
        
        setMainSquare()
       
        setScoreSquare()
        setGoalSquare()
        setScoreText()
        setGoalText()
        setGoalWord()
        
        setTimerSquare()
        realTimer()
        setPhrase()
        setVisualTimer()
        
        
        
        generateSquares(respectiveView: mainSquare, amount: 20)
        
      
    }
    
    
    
    
    func setMainSquare(){
        
        mainSquare.frame = CGRect(x: 12, y: 10, width: viewSize.width * 0.455, height: viewSize.height * 0.431)
        
        mainSquare.backgroundColor = UIColor(red: 1, green: 0.98, blue: 0.91, alpha: 1)
        mainSquare.layer.cornerRadius = 8.0
        mainSquare.layer.borderWidth = 0.5
        mainSquare.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
        view.addSubview(mainSquare)
    }
    
    func setScoreSquare(){
        
        scoreSquare.frame = CGRect(x: 180, y: 572.5, width: 182, height: 77.5)
        scoreSquare.backgroundColor = UIColor(red: 1, green: 0.98, blue: 0.91, alpha: 1)
        scoreSquare.layer.cornerRadius = 8.0
        scoreSquare.clipsToBounds = true
        scoreSquare.text = "Score:"
        scoreSquare.font = UIFont(name: "Arial Rounded MT Bold", size: 32)
        scoreSquare.textAlignment = .left
        scoreSquare.textColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 0.85)
        scoreSquare.layer.borderWidth = 0.5
        scoreSquare.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
        
        
        view.addSubview(scoreSquare)
    }
    
    func setScoreText(){
        
        scoreText.frame = CGRect(x: 180, y: 572.5, width: 168, height: 77.5)
        scoreText.text = "\(actualScore)"
        scoreText.font = UIFont(name: "Arial Rounded MT Bold", size: 35)
        scoreText.textAlignment = .right
        scoreText.textColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0)
        
        view.addSubview(scoreText)
    }
    
    func setGoalSquare(){
        goalSquare.frame = CGRect(x: 12, y: 490, width: 160, height: 160)
        goalSquare.backgroundColor = UIColor(red: 1, green: 0.98, blue: 0.91, alpha: 1)
        goalSquare.layer.cornerRadius = 8.0
        goalSquare.clipsToBounds = true
        goalSquare.layer.borderWidth = 0.5
        goalSquare.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
        
        view.addSubview(goalSquare)
    }
    
    func setGoalText(){
        goalText.frame = CGRect(x: 12, y: 510, width: 160, height: 160)
        goalText.text = "\(actualGoal)"
        goalText.font = UIFont(name: "Arial Rounded MT Bold", size: 55)
        goalText.textAlignment = .center
        goalText.textColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0)
        
        view.addSubview(goalText)
    }
    
    func setGoalWord(){
        goalWord.frame = CGRect(x: 12, y: 440, width: 160, height: 160)
        goalWord.text = "Goal:"
        goalWord.font = UIFont(name: "Arial Rounded MT Bold", size: 40)
        goalWord.textAlignment = .center
        goalWord.textColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 0.85)
        
        view.addSubview(goalWord)
    }
    
    func setPhrase(){
        gamePhrase.frame = CGRect(x: 15, y: 455, width: 350, height: 20)
        gamePhrase.text = "Press the tiles & sum to the goal!"
        gamePhrase.font =  UIFont(name: "Arial Rounded MT Bold", size: 18)
        gamePhrase.textAlignment = .left
        gamePhrase.textColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0)
        
        view.addSubview(gamePhrase)
    }
    
    func setTimerSquare(){
        
        timerSquare.frame = CGRect(x: 180, y: 490, width: 182, height: 77.5)
        timerSquare.backgroundColor = UIColor(red: 1, green: 0.98, blue: 0.91, alpha: 1)
        timerSquare.layer.cornerRadius = 8.0
        timerSquare.clipsToBounds = true
        timerSquare.layer.borderWidth = 0.5
        timerSquare.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
        
        view.addSubview(timerSquare)
    }
    
    func setVisualTimer() {
        
        var xPosition = 188
        var yPosition = 494
        var lineTimer = actualTime
        
        for _ in timeArray.count..<lineTimer{
            
            if timeArray.count < 10 {
            
                if timeArray.count > 4 {
                    yPosition = 529
                }
            
                if xPosition > 346
                {
                    xPosition = 188
                }
                
                let newTimeSquare = UIView()
                
                if timeArray.count > 0 {
                    if timeArray.count == 5 {
                        xPosition = 188
                        newTimeSquare.frame = CGRect(x: xPosition, y: yPosition, width: 32, height: 34)
                    }
                    else {
                    
                    newTimeSquare.frame = CGRect(x: Int(timeArray.last!.frame.minX) + 33, y: yPosition, width: 32, height: 34)
                    }
                }
                else {
                    newTimeSquare.frame = CGRect(x: xPosition, y: yPosition, width: 32, height: 34)
                }
                
                newTimeSquare.backgroundColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 0.8)
                newTimeSquare.layer.cornerRadius = 8.0
                newTimeSquare.clipsToBounds = true
                newTimeSquare.layer.borderWidth = 0.3
                newTimeSquare.layer.borderColor = UIColor(red: 0.7, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
                
                view.addSubview(newTimeSquare)
                timeArray.append(newTimeSquare)
                
                xPosition += 34
                yPosition = 494
                lineTimer = lineTimer - 1
            
            }
        }
    }
    
    func realTimer(){
        
        timeCounter?.invalidate()
        
        timeCounter = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true){ timeCounter in
            if self.actualTime > 0  || self.timeArray.count > 0{
                
                if self.actualTime <= 0 {
                    self.actualTime = 0
                }
                self.fadeSquares(lastSquare: self.timeArray)
                
                self.actualTime -= 1
                
    
            }
            else {
                
                self.endGame()
                
                timeCounter.invalidate()
            }
        }
        
    }
    
    func adjustTimer(){
        
        if self.actualTime > 5 {
            actualTime += 4
        }
        else {
            actualTime += 5
        }
        if actualTime > 10 {
            actualTime = 10
        }
        
        setVisualTimer()

        
    }
    
    
    
    func setGameStack(){
        gameStack.axis = .vertical
        gameStack.distribution = .fillEqually
        gameStack.spacing = 5
        gameStack.alignment = .center
        gameStack.frame = CGRect(x: 12, y: 10, width: 350, height: 450)
        gameStack.backgroundColor = .green//UIColor(red: 1, green: 0.98, blue: 0.91, alpha: 1)
        gameStack.layer.cornerRadius = 8.0
        
        
    
        gameStack.addSubview(firstStack)
        gameStack.addSubview(secondStack)
        gameStack.addSubview(thirdStack)
        gameStack.addSubview(fourthStack)
        gameStack.addSubview(fifthStack)
        
        view.addSubview(gameStack)
        
    }
    
    func setLineStack(){
        // firstStack.frame = CGRect(x: -5, y: 0, width: 350, height: 90)
        firstStack.axis = .horizontal
        firstStack.distribution = .fillEqually
        firstStack.spacing = 5
        firstStack.alignment = .center
        firstStack.backgroundColor = .green
        firstStack.layer.cornerRadius = 8.0
        firstStack.translatesAutoresizingMaskIntoConstraints = false
        
        //secondStack.frame = CGRect(x: -5, y: 5, width: 350, height: 90)
        secondStack.axis = .horizontal
        secondStack.distribution = .fillEqually
        secondStack.spacing = 5
        secondStack.alignment = .center
        secondStack.backgroundColor = .red
        secondStack.layer.cornerRadius = 8.0
        secondStack.translatesAutoresizingMaskIntoConstraints = false
        
        //thirdStack.frame = CGRect(x: -5, y: 10, width: 350, height: 90)
        thirdStack.axis = .horizontal
        thirdStack.distribution = .fillEqually
        thirdStack.spacing = 5
        thirdStack.alignment = .center
        thirdStack.backgroundColor = .purple
        thirdStack.layer.cornerRadius = 8.0
        thirdStack.translatesAutoresizingMaskIntoConstraints = false
        //fourthStack.frame = CGRect(x: -5, y: 15, width: 350, height: 90)
        fourthStack.axis = .horizontal
        fourthStack.distribution = .fillEqually
        fourthStack.spacing = 5
        fourthStack.alignment = .center
        fourthStack.backgroundColor = .yellow
        fourthStack.layer.cornerRadius = 8.0
        fourthStack.translatesAutoresizingMaskIntoConstraints = false
        
        // fifthStack.frame = CGRect(x: -5, y: 20, width: 350, height: 90)
        fifthStack.axis = .horizontal
        fifthStack.distribution = .fillEqually
        fifthStack.spacing = 5
        fifthStack.alignment = .center
        fifthStack.backgroundColor = .red
        fifthStack.layer.cornerRadius = 8.0
        
        fifthStack.translatesAutoresizingMaskIntoConstraints = false
    }
    
    func adjustDifficulty(){
        
        let lowerBound = 10 + actualRound
        let higherBound = 15 + actualRound
        
        let randomNum = Int.random(in: lowerBound..<higherBound)
        
        actualRound += 2
        squareRound += 1
        
        actualGoal = randomNum
        goalText.text = "\(actualGoal)"
    }
    
    func generateSquares(respectiveView: UIView, amount: Int){
        
        var xPosition = 20
        var yPosition = 20
        var count = 0
        
        adjustDifficulty()
        
        
        for _ in 0..<amount {
            
            var randomNum = Int.random(in: -5..<11)
            while randomNum == 0 {
                randomNum = Int.random(in: -5..<11)
            }
            
            let newSquare = gameSquare(value: randomNum, clicked: false)
            newSquare.button.backgroundColor = UIColor(red: 0.65, green: 0.81, blue: 1.0, alpha: 0.9)
            newSquare.button.frame = CGRect(x: xPosition, y: yPosition, width: 80, height: 80)
            newSquare.button.layer.borderWidth = 0.2
            newSquare.button.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
            newSquare.button.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 23)
            if newSquare.value < 0 {
                newSquare.button.backgroundColor = UIColor(red: 1.0, green: 0.61, blue: 0.58, alpha: 0.9)
            }
            
            
            newSquare.button.setTitle("\(randomNum)", for: .normal)
            newSquare.button.layer.cornerRadius = 8.0
     
            newSquare.button.addButtonShadow()
            newSquare.button.addTarget(self, action: #selector(increaseButton), for: .touchDown)
            
            valueSquare.append(newSquare)
            view.addSubview(newSquare.button)
            
            xPosition = xPosition + 85
            
            count += 1
            
            if count > 3 {
                yPosition = yPosition + 85
                xPosition = 20
                count = 0
            }
            
        }
        
    }
    
    func newRound(){
        
        var xPosition = 20
        var yPosition = 20
        var count = 0
        var randomNum: Int = 0
        let roundAddition = 11 + (squareRound / 5)
        
        
        rotateSquares(choosenSquares: choosenSquares)
        choosenSquares = []
        
        adjustDifficulty()
        
        for i in 0..<valueSquare.count{
            
            randomNum = Int.random(in: -5..<roundAddition)
            while randomNum == 0{
                randomNum = Int.random(in: -5..<roundAddition)
            }
            valueSquare[i].value = randomNum
            valueSquare[i].button.setTitle("\(valueSquare[i].value)", for: .normal)
            valueSquare[i].clicked = false
            valueSquare[i].button.frame = CGRect(x: xPosition, y: yPosition, width: 80, height: 80)
            
            UIView.animate(withDuration: 0.2, animations: {
                self.valueSquare[i].button.backgroundColor = UIColor(red: 0.65 , green: 0.81, blue: 1.0, alpha: 0.9)
                
                if self.valueSquare[i].value < 0 {
                    self.valueSquare[i].button.backgroundColor = UIColor(red: 1.0, green: 0.61, blue: 0.58, alpha: 0.9)
                }

            })
            
            valueSquare[i].button.setTitleColor(.white, for: .normal)
            
            
            count += 1
            xPosition += 85
            
            if count > 3 {
                yPosition = yPosition + 85
                xPosition = 20
                count = 0
            }
        }
        
        
        actualScore = actualScore + actualTime + 3
        
        if actualScore >= 1000 {
            scoreText.font = UIFont(name: "Arial Rounded MT Bold", size: 28)
    
        }
        actualSum = 0
        adjustTimer()
        scoreText.text = "\(actualScore)"
        SoundPlayer.playButtonSoundEffect(buttonName: "VictorySound")
    }
    
    @objc func increaseButton(sender: UIButton){
        var cont = 0
        for gameSquare in valueSquare {
            cont += 1
            if gameSquare.button.frame.minX == sender.frame.minX &&
                gameSquare.button.frame.minY == sender.frame.minY &&
                gameSquare.clicked == false {
                
                gameSquare.clicked = true
                actualSum += gameSquare.value
               
                UIView.animate(withDuration: 0.3){
                    sender.frame = CGRect(x: sender.frame.minX - 1, y: sender.frame.minY - 1, width: 82, height: 82)
                    sender.setTitleColor(.black, for: .normal)
                    
                    if gameSquare.value > 0 {
                    sender.backgroundColor = UIColor(red: 0.65, green: 0.81, blue: 1.0, alpha: 0.3)
                    }
                    else {
                    sender.backgroundColor = UIColor(red: 1.0, green: 0.61, blue: 0.58, alpha: 0.3)
                    }
                }
                
                choosenSquares.append(sender)
                
                SoundPlayer.playButtonSoundEffect(buttonName: "buttonClick ")
            }
            else if gameSquare.button.frame.minX == sender.frame.minX &&
                gameSquare.button.frame.minY == sender.frame.minY &&
                gameSquare.clicked == true {
                
                gameSquare.clicked = false
                actualSum -= gameSquare.value
            
                UIView.animate(withDuration: 0.3){
                    sender.frame = CGRect(x: sender.frame.minX + 1, y: sender.frame.minY + 1, width: 80, height: 80)
                    if gameSquare.value > 0 {
                    sender.backgroundColor = UIColor(red: 0.65 , green: 0.81, blue: 1.0, alpha: 0.9)
                    }
                    else {
                    sender.backgroundColor = UIColor(red: 1.0, green: 0.61, blue: 0.58, alpha: 0.9)
                    }
                    sender.setTitleColor(.white, for: .normal)
                }
           
                for i in 0..<choosenSquares.count{
                    
                    if choosenSquares[i] == sender{
                        choosenSquares.remove(at: i)
                        break
                    }
                    
                }

                SoundPlayer.playButtonSoundEffect(buttonName: "buttonDismiss")
            }
            
            
            if actualSum == actualGoal{
                newRound()
            }
        }
        
        
    }
    
    
    func rotateSquares(choosenSquares: [UIButton]) {
        
        UIView.animate(withDuration: 0.2, animations:
            {
                for element in choosenSquares{
                element.alpha = 1.0
                let affineTransform = CGAffineTransform(rotationAngle: CGFloat(Double.pi))
                element.transform = affineTransform
                element.backgroundColor = UIColor(red: 0.65 , green: 0.81, blue: 1.0, alpha: 0.6)

                }
                        })

        UIView.animate(withDuration: 0.2, delay: 0.15, animations:
            {
            for element in choosenSquares{
                element.alpha = 1.0
                let affineTransform = CGAffineTransform(rotationAngle: CGFloat(Double.pi * 2))
                element.transform = affineTransform
                element.backgroundColor = UIColor(red: 1.0, green: 0.61, blue: 0.58, alpha: 0.6)
                }
                
        })
    
    
    
        }
    
    func fadeSquares(lastSquare: [UIView]){
        
        UIView.animate(withDuration: 0.3, animations:
            {
        
                lastSquare.last?.frame = CGRect(x: 211, y: 511, width: 0, height: 0)
                lastSquare.last?.backgroundColor = UIColor(red: 1.0, green: 0.61, blue: 0.58, alpha: 0.9)
                
                lastSquare.last?.alpha = 0.5
            })
        
        if !self.timeArray.isEmpty{
            self.timeArray.removeLast()
            }
    }
    
    
    func endGame () {
        
        endGameSquare.frame = CGRect (x: 0 , y: 0, width: self.viewSize.width, height: self.viewSize.height)
        endGameSquare.alpha = 0
        endGameSquare.backgroundColor = UIColor (red: 0, green: 0, blue: 0, alpha: 0.4)
        
        view.addSubview(endGameSquare)
        
        UIView.animate(withDuration: 0.2, animations: {
            
            self.endGameSquare.alpha = 1.0
            
        })
        
        endOption.frame = CGRect (x: 55, y: 230, width: 265, height: 260)
        endOption.backgroundColor = UIColor(red:1.0, green: 0.9, blue: 0.6, alpha: 0.95)
        endOption.layer.cornerRadius = 8.0
        endOption.layer.borderWidth = 0.5
        endOption.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
        endOption.alpha = 0.0
        
        endText.frame = CGRect (x: 55, y: 235, width: 265, height: 50)
        endText.text = "You ran out of time!\n Score: \(actualScore)"
        endText.textAlignment = .center
        endText.numberOfLines = 0
        endText.textColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0)
        endText.font = UIFont(name: "Arial Rounded MT Bold", size: 21)
        endText.alpha = 0.0
        
        playAgainText.frame = CGRect (x: 55, y: 293, width: 265, height: 50)
        playAgainText.text = "Play again?"
        playAgainText.textAlignment = .center
        playAgainText.textColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0)
        playAgainText.font = UIFont(name: "Arial Rounded MT Bold", size: 30)
        playAgainText.alpha = 0.0
        
        playAgain.frame = CGRect(x: 91, y: 340, width: 190, height: 60)
        playAgain.backgroundColor = .orange
        playAgain.layer.cornerRadius = 8.0
        playAgain.setTitle("YES!!!", for: .normal)
        playAgain.layer.borderWidth = 0.5
        playAgain.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
        playAgain.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 40)
        playAgain.alpha = 0.0
        
        playAgain.addTarget(self, action: #selector(reInitGame), for: .touchUpInside)
        
        
        backMenu.frame = CGRect(x: 121, y: 410, width: 130, height: 40)
        backMenu.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.3)
        backMenu.layer.cornerRadius = 8.0
        backMenu.setTitle("Read about me :)", for: .normal)
        backMenu.layer.borderWidth = 0.5
        backMenu.layer.borderColor = UIColor(red: 0.6, green: 0.49, blue: 0.2, alpha: 1.0).cgColor
        backMenu.titleLabel?.font = UIFont(name: "Arial Rounded MT Bold", size: 14)
        backMenu.alpha = 0.0
        
        backMenu.addTarget(self, action: #selector(returnMenu), for: .touchUpInside)
        
        view.addSubview(endOption)
        view.addSubview(endText)
        view.addSubview(playAgainText)
        view.addSubview(playAgain)
        view.addSubview(backMenu)
        
        UIView.animate(withDuration: 0.2, delay: 0.15, animations:{
          
           self.endOption.alpha = 1.0
           self.endText.alpha = 1.0
           self.playAgainText.alpha = 1.0
           self.playAgain.alpha = 1.0
           self.backMenu.alpha = 1.0
            
        })
        SoundPlayer.playButtonSoundEffect(buttonName: "EndSound ")
    }
    
    func setSoundTrack(noteString: String){
        
        //        guard let soundtrackPath = Bundle.main.path(forResource: "gameSoundtrack", ofType: "mp3"),
        //        soundTrack?.setVolume(10, fadeDuration: 0)
        
        
        guard let url = Bundle.main.url(forResource: noteString, withExtension: "mp3") else {return}
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            //player?.numberOfLoops = -1
            
            
            guard let player = player else { return }
            player.play()
        } catch let error {
            print(error.localizedDescription)
        }
        
    }
    
    @objc func reInitGame(sender: UIButton!){
        
        self.endGameSquare.removeFromSuperview()
        self.endOption.removeFromSuperview()
        self.endText.removeFromSuperview()
        self.playAgainText.removeFromSuperview()
        self.playAgain.removeFromSuperview()
        self.backMenu.removeFromSuperview()
        
        self.actualSum = 0
        self.actualScore = 0
        self.actualGoal = 0
        
        self.actualRound = 0
        
        self.goalText.text = "\(actualGoal)"
        
        self.newRound()
        
        for element in timeArray{
            element.removeFromSuperview()
        }
        
        self.actualScore = 0
        self.scoreText.text = "\(actualScore)"
        
        self.timeArray = []
        self.actualTime = 10
        self.realTimer()
        self.setVisualTimer()
        
    }
    
    @objc func returnMenu(sender: UIButton!){
        
        PlaygroundSupport.PlaygroundPage.current.liveView = aboutViewController()
        
    }
}

extension UIView{
    
    func addShadow(){
        self.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.4).cgColor // 0.3
        self.layer.shadowOffset = CGSize(width: 0, height: 3)
        self.layer.shadowOpacity = 1.0 //0.45
        self.layer.shadowRadius = 1.0
    }
    
    func addButtonShadow(){
        self.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.2).cgColor
        self.layer.shadowOffset = CGSize(width: 0, height: 3)
        self.layer.shadowOpacity = 0.25
        self.layer.shadowRadius = 8.0
    }
}
