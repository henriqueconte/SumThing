import UIKit
import PlaygroundSupport
import AVFoundation

/*:
# SumThing

 
 
 ### Game objective:
 This application was developed in order to help young students to improve their knowledge roots in mathematics - addition and subtraction - in a funny way. Its challenging goals defies us to think faster and go beyond our limits.
 
 ### Context:
 Students from all over the world face barriers when mathematics complexity starts growing up, both for the poor educational formation and for the lack of teaching resources. SumThing gets together both topics since it is accessible for children, teenagers, and people with disabilities, such as color blindness and autism.
*/







PlaygroundPage.current.liveView = MenuViewController()

